'use strict'
// main

start()
function start(){
    
    listenTableEvent()
    

}

function listenTableEvent() {
    var table = $('#myTableEditable').DataTable({
        'searching': false,
        paging: true,
        scrollX: true,
        scrollY: 300,
        "bLengthChange": false,
        "sort": false,
        keys: true,
        "columnDefs": [
            {
                "targets": [],
                "visible": false,
                "searchable": false
            }
        ]
    })
    var oldValue;
    var newValue
    table
        .on('key', function (e, datatable, key, cell, originalEvent) {
            //1. neu key = 13 (enter) => Move down
            if (key == 13) {
                table.keys.move('down');
            }


            table.columns.adjust()
        })
        .on('key-focus', function (e, datatable, cell) {
            //1. Kiem tra co the select ko? & co thuoc tinh editable = true ko?
            var cellElement = cell.node();
            var isSelect = $(cell.node()).find('select').length
            var isEditableCell = $(cellElement).attr('isEditable')
            oldValue = $(cellElement).text().trim();

            //1.1 Neu co the select va editable
            if (isSelect && isEditableCell) {

                oldValue = $(cellElement).find('select option:selected').val();

            }

            //1.2 Neu ko co the select
            if (isEditableCell && isSelect == false) {
                //1.2.1 Neu "editable" => them the input de Edit

                if (isEditableCell) {
                    addInputElement(cellElement)
                }
            }


            table.columns.adjust()
        })
        .on('key-blur', function (e, datatable, cell) {
            // 1. Đóng thẻ input
            var inputElement = document.querySelector('#jsCellFocus')
            var isSelect = $(cell.node()).find('select').length
            var isEditableCell = $(cell.node()).attr('isEditable')
            if (inputElement) {
                var data = getNewData(cell.node())

                //2. Kiem tra value co thay doi hay ko? => co thi luu vao database
                newValue = data.newValue
                if (newValue != oldValue) {
                    updateData(data)  // true || false
                }

            }

          

            // Neu co selected va editable
            if (isSelect && isEditableCell) {
                // newValue = $(cell.node()).find('select option:selected').val();
                var data = getNewData(cell.node())
                newValue = data.newValue;
                if (newValue != oldValue) {
                    updateData(data)  // true || false
                }
            }

            table.columns.adjust()
        })
    
}

function addInputElement(cellElement) {
    var name = $(cellElement).attr('name')
    var value = cellElement.textContent.trim()
    $(cellElement).html("<input name ='" + name + "' value = '" + value + "' style ='width: " + cellElement.offsetWidth + "px; height :" + (cellElement.offsetHeight) + "px' id='jsCellFocus'/>")
        .css({
            'padding': 0,
            'outline': '1px solid #ac1212',
            'outline-offset': '-3px',
            'background-color': '#f8e6e6 !important',
            'box-shadow': 'none'
        })
    $('#jsCellFocus').css({
        'background': 'transparent',
        'border': '0px solid transparent',
        'outline': 'none',
        

    }).select()

}
// Viet lai Ham getData dau vao la cell
// Kiem tra cell co the input hay select
function getNewData(tdElement) {
    //1. Kiem tra co input ko?
    var isInput = $(tdElement).find('input').length;
    var isSelect = $(tdElement).find('select').length;
    var trparent = $(tdElement).parent();
    var name = $(tdElement).attr('name')
    var recordID = $(trparent).attr('id')

    var newValue
    if (isInput) {
        newValue = $(tdElement).find('input').val()
        $(tdElement).html(newValue).css({
            'background': 'transparent',
            'outline': 'none'
        })
    }
    if (isSelect) {
        newValue = $(tdElement).find('select option:selected').val()
    }
    var data = {
        recordID: recordID,
        name: name,
        newValue: newValue,
    }
    return data;
}

function updateData(data) {

    console.log('Update data', data)
}

function getTableHeaderColumn(callback) {
    var url = 'http://localhost:8080/Die_Launching_Control/DieLaunchColumnManage'
    fetch(url)
        .then(function (response) {
            return response.json()
        })
        .then(callback)
}




function renderTableHeader() {
    getTableHeaderColumn(function (header) {
        var renderTheadAreas = $('#myTableEditable thead').html('')
        var content = ''
        for (var i = 0; i < header.length; i++){
            content += '<th>'+header[i].Col_Name+'</th>'
        }
       renderTheadAreas.html('<tr>'+content+'</tr>')
    })
    
}


function getRecord() {

}
